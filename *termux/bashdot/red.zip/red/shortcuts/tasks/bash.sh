#!/data/data/com.termux/files/usr/bin/bash
termux-toast hello
bash ~/bash
termux-toast "done bash"
#console.log ("123");
