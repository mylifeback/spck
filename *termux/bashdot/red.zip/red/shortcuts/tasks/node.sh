#!/data/data/com.termux/files/usr/bin/bash
node ~/nodejs
echo "done node"
#console.log ("123");
